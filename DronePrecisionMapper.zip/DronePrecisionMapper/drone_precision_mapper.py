# -*- coding: utf-8 -*-
"""
Drone Precision Mapper Plugin
Main plugin class for QGIS integration
"""

import os
import math
import numpy as np
import traceback
import tempfile
from pathlib import Path
from PyQt5.QtWidgets import (
    QAction, QFileDialog, QMessageBox, QProgressBar, 
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QGroupBox, QRadioButton, QLineEdit, QTextEdit,
    QWidget, QDialog, QApplication
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QIcon, QColor

# QGIS imports
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsRaster, QgsPointXY,
    QgsCoordinateReferenceSystem
)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker
from qgis.utils import iface

# Import our image processor
from .image_processor import ImageProcessor


class DronePrecisionMapper:
    """Main plugin class for Drone Precision Mapper."""
    
    def __init__(self, iface):
        """Initialize the plugin."""
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.dock_widget = None
        self.active_tool = None
        self.processed_layers = []
        
        # Plugin actions
        self.action = None
        self.menu = None
        
    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        # Create action
        self.action = QAction(
            QIcon(":/plugins/drone_precision_mapper/icon.png"),
            "Drone Precision Mapper",
            self.iface.mainWindow()
        )
        self.action.triggered.connect(self.run)
        self.action.setEnabled(True)
        
        # Add toolbar button and menu item
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Drone Precision Mapper", self.action)
        
    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.iface.removePluginMenu("&Drone Precision Mapper", self.action)
        self.iface.removeToolBarIcon(self.action)
        
        # Clean up any active tools
        if self.active_tool:
            self.canvas.unsetMapTool(self.active_tool)
            self.active_tool = None
            
        # Close dock widget if open
        if self.dock_widget:
            self.dock_widget.close()
            
    def run(self):
        """Run method that performs all the real work."""
        # Create and show the main dialog
        self.dialog = DronePrecisionMapperDialog(self.iface, self)
        self.dialog.show()


class DronePrecisionMapperDialog(QDialog):
    """Main dialog for the Drone Precision Mapper plugin."""
    
    def __init__(self, iface, plugin):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.plugin = plugin
        self.canvas = iface.mapCanvas()
        self.processor = None
        
        self.setup_ui()
        
    def setup_ui(self):
        """Setup the user interface."""
        self.setWindowTitle("Drone Precision Mapper")
        self.setMinimumSize(500, 400)
        
        layout = QVBoxLayout()
        
        # Mode selection
        mode_group = QGroupBox("Processing Mode")
        mode_layout = QVBoxLayout()
        
        self.single_mode_radio = QRadioButton("Single Image")
        self.batch_mode_radio = QRadioButton("Batch Processing (Multiple Images)")
        self.single_mode_radio.setChecked(True)
        
        mode_layout.addWidget(self.single_mode_radio)
        mode_layout.addWidget(self.batch_mode_radio)
        mode_group.setLayout(mode_layout)
        layout.addWidget(mode_group)
        
        # File selection
        file_group = QGroupBox("File Selection")
        file_layout = QVBoxLayout()
        
        # Single image selection
        single_layout = QHBoxLayout()
        self.single_file_edit = QLineEdit()
        self.single_file_edit.setPlaceholderText("Select a single drone image...")
        self.single_file_btn = QPushButton("Browse...")
        self.single_file_btn.clicked.connect(self.select_single_file)
        single_layout.addWidget(self.single_file_edit)
        single_layout.addWidget(self.single_file_btn)
        file_layout.addLayout(single_layout)
        
        # Batch folder selection
        batch_layout = QHBoxLayout()
        self.batch_folder_edit = QLineEdit()
        self.batch_folder_edit.setPlaceholderText("Select folder containing drone images...")
        self.batch_folder_btn = QPushButton("Browse...")
        self.batch_folder_btn.clicked.connect(self.select_batch_folder)
        batch_layout.addWidget(self.batch_folder_edit)
        batch_layout.addWidget(self.batch_folder_btn)
        file_layout.addLayout(batch_layout)
        
        file_group.setLayout(file_layout)
        layout.addWidget(file_group)
        
        # Progress and status
        status_group = QGroupBox("Status")
        status_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        status_layout.addWidget(self.progress_bar)
        
        self.status_text = QTextEdit()
        self.status_text.setMaximumHeight(150)
        self.status_text.setReadOnly(True)
        status_layout.addWidget(self.status_text)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.process_btn = QPushButton("Process Images")
        self.process_btn.clicked.connect(self.process_images)
        self.process_btn.setEnabled(False)
        
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.close)
        
        button_layout.addWidget(self.process_btn)
        button_layout.addWidget(self.close_btn)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
        # Connect mode changes
        self.single_mode_radio.toggled.connect(self.on_mode_changed)
        self.batch_mode_radio.toggled.connect(self.on_mode_changed)
        
        # Initial mode setup
        self.on_mode_changed()
        
    def on_mode_changed(self):
        """Handle mode selection changes."""
        if self.single_mode_radio.isChecked():
            self.single_file_edit.setEnabled(True)
            self.single_file_btn.setEnabled(True)
            self.batch_folder_edit.setEnabled(False)
            self.batch_folder_btn.setEnabled(False)
        else:
            self.single_file_edit.setEnabled(False)
            self.single_file_btn.setEnabled(False)
            self.batch_folder_edit.setEnabled(True)
            self.batch_folder_btn.setEnabled(True)
            
        self.update_process_button()
        
    def select_single_file(self):
        """Select a single image file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Drone Image",
            "",
            "Image Files (*.jpg *.jpeg *.tiff *.tif *.png)"
        )
        if file_path:
            self.single_file_edit.setText(file_path)
            self.update_process_button()
            
    def select_batch_folder(self):
        """Select a folder for batch processing."""
        folder_path = QFileDialog.getExistingDirectory(
            self,
            "Select Folder with Drone Images"
        )
        if folder_path:
            self.batch_folder_edit.setText(folder_path)
            self.update_process_button()
            
    def update_process_button(self):
        """Update the process button state."""
        if self.single_mode_radio.isChecked():
            enabled = bool(self.single_file_edit.text().strip())
        else:
            enabled = bool(self.batch_folder_edit.text().strip())
            
        self.process_btn.setEnabled(enabled)
        
    def log_message(self, message):
        """Add a message to the status text."""
        self.status_text.append(message)
        
    def process_images(self):
        """Process the selected images."""
        try:
            if self.single_mode_radio.isChecked():
                self.process_single_image()
            else:
                self.process_batch_images()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Processing failed: {str(e)}")
            self.log_message(f"ERROR: {str(e)}")
            
    def process_single_image(self):
        """Process a single image."""
        image_path = self.single_file_edit.text().strip()
        if not Path(image_path).exists():
            QMessageBox.warning(self, "Warning", "Selected image file does not exist.")
            return
            
        self.log_message("Processing single image...")
        
        # Process synchronously to avoid threading issues
        try:
            from .image_processor import georeference_image, PrecisionClickTool
            
            result_params = georeference_image(image_path, self.log_message)
            if result_params:
                # Create precision click tool
                precision_tool = PrecisionClickTool(self.canvas, result_params)
                
                # Update canvas
                self.canvas.setExtent(result_params['layer'].extent())
                self.canvas.refresh()
                
                # Set the tool
                self.canvas.setMapTool(precision_tool)
                
                self.log_message("✅ Single image processed successfully!")
                self.log_message("Precision click tool activated. Click on the image to get coordinates.")
                self.close()
            else:
                self.log_message("❌ Single image processing failed.")
                
        except Exception as e:
            self.log_message(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Processing failed: {str(e)}")
        
    def process_batch_images(self):
        """Process multiple images in batch."""
        folder_path = self.batch_folder_edit.text().strip()
        if not Path(folder_path).exists():
            QMessageBox.warning(self, "Warning", "Selected folder does not exist.")
            return
            
        self.log_message("Processing batch images...")
        
        # Process synchronously to avoid threading issues
        try:
            from .image_processor import process_multiple_drone_photos, MultiLayerPrecisionClickTool
            
            processed_layers = process_multiple_drone_photos(folder_path, self.log_message, self.progress_bar)
            
            if processed_layers:
                # Create multi-layer precision tool
                multi_tool = MultiLayerPrecisionClickTool(self.canvas, processed_layers)
                
                # Set extent to show all layers
                all_extents = [layer_data['params']['layer'].extent() for layer_data in processed_layers]
                combined_extent = all_extents[0]
                for extent in all_extents[1:]:
                    combined_extent.combineExtentWith(extent)
                self.canvas.setExtent(combined_extent)
                self.canvas.refresh()
                
                # Set the tool
                self.canvas.setMapTool(multi_tool)
                
                self.progress_bar.setVisible(False)
                self.log_message(f"✅ Successfully processed {len(processed_layers)} images!")
                self.log_message("Multi-layer precision tool activated.")
                self.log_message("Use keyboard shortcuts: N (next), P (previous), L (list)")
                self.close()
            else:
                self.progress_bar.setVisible(False)
                self.log_message("❌ Batch processing failed.")
                
        except Exception as e:
            self.progress_bar.setVisible(False)
            self.log_message(f"❌ Error: {str(e)}")
            QMessageBox.critical(self, "Error", f"Processing failed: {str(e)}") 