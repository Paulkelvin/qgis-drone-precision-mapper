# -*- coding: utf-8 -*-
"""
Image processing module for Drone Precision Mapper
Contains all the georeferencing and coordinate transformation logic
"""

import os
import math
import numpy as np
import traceback
import tempfile
from pathlib import Path
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtGui import QColor

# QGIS imports
from qgis.core import (
    QgsProject, QgsRasterLayer, QgsRaster, QgsPointXY,
    QgsCoordinateReferenceSystem
)
from qgis.gui import QgsMapToolEmitPoint, QgsVertexMarker

# GDAL imports
from osgeo import gdal, osr

# PIL imports
from PIL import Image, ExifTags
from PIL.TiffImagePlugin import IFDRational

# Configure GDAL
gdal.UseExceptions()
gdal.AllRegister()


def convert_rational_to_float(value, log_func=None):
    """Converts an EXIF value to a float."""
    # Case 1: Pillow's special IFDRational type
    if isinstance(value, IFDRational):
        return float(value)
        
    # Case 2: Standard rational tuple (numerator, denominator)
    if isinstance(value, tuple) and len(value) == 2:
        try:
            num = float(value[0])
            den = float(value[1])
            return 0.0 if den == 0 else num / den
        except (ValueError, TypeError):
            pass

    # Case 3: Already a number (int or float)
    if isinstance(value, (int, float)):
        return float(value)

    # Case 4: A single number in a tuple/list, e.g., (5.0,)
    if isinstance(value, (tuple, list)) and len(value) == 1:
        try:
            return float(value[0])
        except (ValueError, TypeError):
            pass

    # Case 5: A number represented as a string, e.g., '5.0'
    if isinstance(value, str):
        try:
            return float(value)
        except (ValueError, TypeError):
            pass

    # If all conversions fail, print a warning and return 0.0
    if log_func:
        log_func(f"Warning: Could not convert value '{value}' to float. Using 0.0.")
    return 0.0
    
def convert_dms_to_degrees(value, log_func=None):
    """Converts a GPS coordinate from Degrees/Minutes/Seconds (DMS) format to decimal degrees."""
    d = convert_rational_to_float(value[0], log_func)
    m = convert_rational_to_float(value[1], log_func)
    s = convert_rational_to_float(value[2], log_func)
    return d + (m / 60.0) + (s / 3600.0)
    
def get_exif_data(img, log_func=None):
    """Extracts and decodes EXIF data from a Pillow Image object."""
    exif_data = {}
    info = img.getexif()
    if not info:
        if log_func:
            log_func("Warning: No EXIF data found in the image.")
        return {}

    for tag_id, value in info.items():
        tag_name = ExifTags.TAGS.get(tag_id, tag_id)
        if tag_name != "GPSInfo":
            exif_data[tag_name] = value

    try:
        gps_ifd = info.get_ifd(ExifTags.IFD.GPSInfo)
        if gps_ifd:
            gps_data = {}
            for tag_id, value in gps_ifd.items():
                sub_tag_name = ExifTags.GPSTAGS.get(tag_id, tag_id)
                gps_data[sub_tag_name] = value
            exif_data["GPSInfo"] = gps_data
    except (KeyError, TypeError):
        if log_func:
            log_func("Warning: GPSInfo tag found, but failed to retrieve GPS data dictionary (IFD).")
    except Exception as e:
        if log_func:
            log_func(f"An unexpected error occurred while processing GPS data: {e}")

    exif_data['LensModel'] = info.get(42036, 'Unknown')
    return exif_data
    
def get_lens_correction_from_exif(image_path, log_func=None):
    """Attempts to extract lens distortion parameters from EXIF."""
    try:
        import exiftool
        with exiftool.ExifTool() as et:
            metadata = et.get_metadata(image_path)
            distortion_params_str = metadata.get("XMP:LensDistortionParams", "0.0 0.0 0.0")
            k1 = float(distortion_params_str.split()[0])
            if log_func:
                log_func(f"Found lens distortion parameter k1: {k1}")
            return k1
    except Exception as e:
        if log_func:
            log_func(f"Lens correction extraction failed, using fallback value. Reason: {e}")
        return 0.002
        
def apply_distortion_correction(px, py, width, height, k1):
    """Applies a simple radial distortion correction (k1) to a pixel coordinate."""
    if k1 == 0:
        return px, py

    center_x, center_y = width / 2.0, height / 2.0
    xn = (px - center_x) / center_x
    yn = (py - center_y) / center_y
    r_sq = xn**2 + yn**2
    correction_factor = 1 + k1 * r_sq
    xn_corr = xn * correction_factor
    yn_corr = yn * correction_factor
    px_corr = center_x + xn_corr * center_x
    py_corr = center_y + yn_corr * center_y
    return px_corr, py_corr
        
def georeference_image(image_path, log_func=None):
    """Reads an image, extracts EXIF GPS data, and creates a georeferenced raster layer."""
    temp_path = None
    mem_ds = None
    driver = None
    layer = None
    
    try:
        img = Image.open(image_path).convert('RGB')
        exif = get_exif_data(img, log_func)
        gps_info = exif.get("GPSInfo")

        if not gps_info or 'GPSLatitude' not in gps_info or 'GPSLongitude' not in gps_info:
            raise ValueError("Missing essential GPSLatitude or GPSLongitude in EXIF data.")

        lat = convert_dms_to_degrees(gps_info['GPSLatitude'], log_func)
        if gps_info.get('GPSLatitudeRef') == 'S': lat = -lat

        lon = convert_dms_to_degrees(gps_info['GPSLongitude'], log_func)
        if gps_info.get('GPSLongitudeRef') == 'W': lon = -lon

        altitude = convert_rational_to_float(gps_info.get('GPSAltitude', 100.0), log_func)
        focal_length = convert_rational_to_float(exif.get('FocalLength', 8.0), log_func)
        
        if focal_length == 0:
            raise ValueError("Focal length from EXIF is zero, cannot calculate ground resolution.")

        sensor_width_mm = 6.17
        width, height = img.size
        
        ground_width_m = (sensor_width_mm * altitude) / focal_length
        meters_per_pixel = ground_width_m / width

        m_per_deg_lon = 111320 * math.cos(math.radians(lat))
        m_per_deg_lat = 111320
        pixel_width_deg = meters_per_pixel / m_per_deg_lon
        pixel_height_deg = meters_per_pixel / m_per_deg_lat

        top_left_lon = lon - (width / 2.0) * pixel_width_deg
        top_left_lat = lat + (height / 2.0) * pixel_height_deg

        geotransform = (top_left_lon, pixel_width_deg, 0, top_left_lat, 0, -pixel_height_deg)

        mem_ds = gdal.GetDriverByName('MEM').Create('', width, height, 3, gdal.GDT_Byte)
        mem_ds.SetGeoTransform(geotransform)
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        mem_ds.SetProjection(srs.ExportToWkt())

        np_img = np.array(img)
        for i in range(3):
            mem_ds.GetRasterBand(i + 1).WriteArray(np_img[:, :, i])

        # Create temporary file
        with tempfile.NamedTemporaryFile(suffix='.tif', delete=False) as tmp_file:
            temp_path = tmp_file.name
        
        driver = gdal.GetDriverByName('GTiff')
        
        try:
            output_ds = driver.CreateCopy(temp_path, mem_ds)
            if output_ds is None:
                raise RuntimeError(f"GDAL CreateCopy failed for path: {temp_path}")
            output_ds = None
        except Exception as e:
            if log_func:
                log_func(f"GDAL CreateCopy error: {e}")
                log_func("Attempting to use memory-only approach...")
            layer_name = Path(image_path).stem
            layer = QgsRasterLayer(f"file://{image_path}", layer_name)
            if not layer.isValid():
                raise Exception(f"Failed to load the image as raster layer: {layer.error().summary()}")
            
            layer.dataProvider().setNoDataValue(1, 0)
            return {
                'image_width': width, 'image_height': height,
                'distortion_k1': get_lens_correction_from_exif(image_path, log_func), 
                'layer': layer
            }
        
        mem_ds = None 
        driver = None

        layer_name = Path(image_path).stem
        layer = QgsRasterLayer(temp_path, layer_name)
        if not layer.isValid():
            raise Exception(f"Failed to load the georeferenced layer: {layer.error().summary()}")

        QgsProject.instance().addMapLayer(layer)
        
        distortion_k1 = get_lens_correction_from_exif(image_path, log_func)

        if log_func:
            log_func(f"Center Coordinates: Lat={lat:.6f}°, Lon={lon:.6f}°")
            log_func(f"Altitude: {altitude:.2f} m | Ground Resolution: {meters_per_pixel:.3f} m/pixel")
        
        return {
            'image_width': width, 'image_height': height,
            'distortion_k1': distortion_k1, 'layer': layer
        }

    except Exception as e:
        if log_func:
            log_func(f"Error during georeferencing: {str(e)}")
        return None
    
    finally:
        mem_ds = None
        driver = None


def process_multiple_drone_photos(folder_path, log_func=None, progress_bar=None):
    """Process multiple drone photos in a folder for batch georeferencing."""
    image_extensions = ['.jpg', '.jpeg', '.tiff', '.tif', '.png']
    image_folder = Path(folder_path)
    
    if not image_folder.exists():
        if log_func:
            log_func(f"Error: Folder does not exist: {folder_path}")
        return []
    
    # Find all image files
    image_files = []
    for ext in image_extensions:
        image_files.extend(image_folder.glob(f"*{ext}"))
        image_files.extend(image_folder.glob(f"*{ext.upper()}"))
    
    if not image_files:
        if log_func:
            log_func(f"No image files found in: {folder_path}")
        return []
    
    if log_func:
        log_func(f"Found {len(image_files)} image files to process...")
    
    processed_layers = []
    successful_count = 0
    
    for i, image_path in enumerate(image_files):
        if log_func:
            log_func(f"Processing {i+1}/{len(image_files)}: {image_path.name}")
        
        if progress_bar:
            progress_bar.setValue(int((i / len(image_files)) * 100))
            progress_bar.setVisible(True)
        
        try:
            result_params = georeference_image(str(image_path), log_func)
            if result_params:
                processed_layers.append({
                    'image_path': str(image_path),
                    'params': result_params
                })
                successful_count += 1
                if log_func:
                    log_func(f"✅ {image_path.name}")
            else:
                if log_func:
                    log_func(f"❌ {image_path.name}")
        except Exception as e:
            if log_func:
                log_func(f"❌ {image_path.name}: {str(e)}")
    
    if progress_bar:
        progress_bar.setValue(100)
    
    if log_func:
        log_func(f"Successfully processed: {successful_count}/{len(image_files)} images")
    
    return processed_layers


class PrecisionClickTool(QgsMapToolEmitPoint):
    """A QGIS Map Tool that corrects a clicked point for lens distortion."""
    
    def __init__(self, canvas, georef_params):
        super().__init__(canvas)
        self.georef_params = georef_params
        self.canvas = canvas
        
        self.marker = QgsVertexMarker(canvas)
        self.marker.setColor(QColor("red"))
        self.marker.setIconSize(10)
        self.marker.setIconType(QgsVertexMarker.ICON_CROSS)
        self.marker.setPenWidth(2)
        
        self.uncorrected_marker = QgsVertexMarker(canvas)
        self.uncorrected_marker.setColor(QColor("cyan"))
        self.uncorrected_marker.setIconSize(8)
        self.uncorrected_marker.setIconType(QgsVertexMarker.ICON_BOX)
        self.uncorrected_marker.setPenWidth(1)

    def canvasReleaseEvent(self, event):
        layer = self.georef_params['layer']
        if not layer or not isinstance(layer, QgsRasterLayer): return

        clicked_map_point = self.toMapCoordinates(event.pos())
        self.uncorrected_marker.setCenter(clicked_map_point)
        
        # Get coordinate transformation
        provider = layer.dataProvider()
        geotransform = provider.extent()
        
        if not geotransform.isNull():
            width = provider.xSize()
            height = provider.ySize()
            pixel_width = geotransform.width() / width
            pixel_height = geotransform.height() / height
            x_origin = geotransform.xMinimum()
            y_origin = geotransform.yMaximum()
            
            px = (clicked_map_point.x() - x_origin) / pixel_width
            py = (y_origin - clicked_map_point.y()) / pixel_height
            
            # Apply distortion correction
            px_corr, py_corr = apply_distortion_correction(
                px, py,
                self.georef_params['image_width'], self.georef_params['image_height'],
                self.georef_params['distortion_k1'])
            
            corrected_map_point = QgsPointXY(
                x_origin + px_corr * pixel_width,
                y_origin - py_corr * pixel_height
            )

            self.marker.setCenter(corrected_map_point)
            dist_m = clicked_map_point.distance(corrected_map_point) * 111320
            
            print(f"\n--- Precision Click ---")
            print(f"Clicked (Uncorrected): Lat={clicked_map_point.y():.6f}, Lon={clicked_map_point.x():.6f}")
            print(f"Result  (Corrected):  Lat={corrected_map_point.y():.6f}, Lon={corrected_map_point.x():.6f}")
            print(f"Correction Distance:  ~{dist_m:.3f} meters")
            
    def apply_distortion_correction(self, px, py, width, height, k1):
        """Applies distortion correction to pixel coordinates."""
        if k1 == 0:
            return px, py

        center_x, center_y = width / 2.0, height / 2.0
        xn = (px - center_x) / center_x
        yn = (py - center_y) / center_y
        r_sq = xn**2 + yn**2
        correction_factor = 1 + k1 * r_sq
        xn_corr = xn * correction_factor
        yn_corr = yn * correction_factor
        px_corr = center_x + xn_corr * center_x
        py_corr = center_y + yn_corr * center_y
        return px_corr, py_corr


class MultiLayerPrecisionClickTool(QgsMapToolEmitPoint):
    """A QGIS Map Tool that works with multiple layers."""
    
    def __init__(self, canvas, processed_layers):
        super().__init__(canvas)
        self.processed_layers = processed_layers
        self.current_layer_index = 0
        self.canvas = canvas
        
        # Create markers for each layer
        self.markers = []
        self.uncorrected_markers = []
        
        for i, layer_data in enumerate(processed_layers):
            # Corrected marker (red)
            marker = QgsVertexMarker(canvas)
            marker.setColor(QColor("red"))
            marker.setIconSize(10)
            marker.setIconType(QgsVertexMarker.ICON_CROSS)
            marker.setPenWidth(2)
            marker.setVisible(i == 0)
            
            # Uncorrected marker (cyan)
            uncorrected_marker = QgsVertexMarker(canvas)
            uncorrected_marker.setColor(QColor("cyan"))
            uncorrected_marker.setIconSize(8)
            uncorrected_marker.setIconType(QgsVertexMarker.ICON_BOX)
            uncorrected_marker.setPenWidth(1)
            uncorrected_marker.setVisible(i == 0)
            
            self.markers.append(marker)
            self.uncorrected_markers.append(uncorrected_marker)
        
        print(f"\n--- Multi-Layer Precision Tool Activated ---")
        print(f"Current layer: {processed_layers[0]['image_path']}")
        print(f"Use keyboard shortcuts:")
        print(f"  'N' - Next layer")
        print(f"  'P' - Previous layer")
        print(f"  'L' - List all layers")
        print(f"Click on the image to get distortion-corrected coordinates.")
        
    def canvasReleaseEvent(self, event):
        if not self.processed_layers:
            return
            
        current_layer_data = self.processed_layers[self.current_layer_index]
        layer = current_layer_data['params']['layer']
        
        if not layer or not isinstance(layer, QgsRasterLayer):
            return

        clicked_map_point = self.toMapCoordinates(event.pos())
        
        # Update markers for current layer
        self.uncorrected_markers[self.current_layer_index].setCenter(clicked_map_point)
        
        # Get coordinate transformation
        provider = layer.dataProvider()
        geotransform = provider.extent()
        
        if not geotransform.isNull():
            width = provider.xSize()
            height = provider.ySize()
            pixel_width = geotransform.width() / width
            pixel_height = geotransform.height() / height
            x_origin = geotransform.xMinimum()
            y_origin = geotransform.yMaximum()
            
            px = (clicked_map_point.x() - x_origin) / pixel_width
            py = (y_origin - clicked_map_point.y()) / pixel_height
            
            # Apply distortion correction
            px_corr, py_corr = apply_distortion_correction(
                px, py,
                current_layer_data['params']['image_width'],
                current_layer_data['params']['image_height'],
                current_layer_data['params']['distortion_k1'])
            
            corrected_map_point = QgsPointXY(
                x_origin + px_corr * pixel_width,
                y_origin - py_corr * pixel_height
            )

            self.markers[self.current_layer_index].setCenter(corrected_map_point)
            dist_m = clicked_map_point.distance(corrected_map_point) * 111320
            
            print(f"\n--- Precision Click (Layer {self.current_layer_index + 1}) ---")
            print(f"Image: {Path(current_layer_data['image_path']).name}")
            print(f"Clicked (Uncorrected): Lat={clicked_map_point.y():.6f}, Lon={clicked_map_point.x():.6f}")
            print(f"Result  (Corrected):  Lat={corrected_map_point.y():.6f}, Lon={corrected_map_point.x():.6f}")
            print(f"Correction Distance:  ~{dist_m:.3f} meters")
            
    def apply_distortion_correction(self, px, py, width, height, k1):
        """Applies distortion correction to pixel coordinates."""
        if k1 == 0:
            return px, py

        center_x, center_y = width / 2.0, height / 2.0
        xn = (px - center_x) / center_x
        yn = (py - center_y) / center_y
        r_sq = xn**2 + yn**2
        correction_factor = 1 + k1 * r_sq
        xn_corr = xn * correction_factor
        yn_corr = yn * correction_factor
        px_corr = center_x + xn_corr * center_x
        py_corr = center_y + yn_corr * center_y
        return px_corr, py_corr
        
    def keyPressEvent(self, event):
        if not self.processed_layers:
            return
            
        key = event.key()
        
        if key == ord('N') or key == ord('n'):  # Next layer
            self.current_layer_index = (self.current_layer_index + 1) % len(self.processed_layers)
            self._update_layer_visibility()
            
        elif key == ord('P') or key == ord('p'):  # Previous layer
            self.current_layer_index = (self.current_layer_index - 1) % len(self.processed_layers)
            self._update_layer_visibility()
            
        elif key == ord('L') or key == ord('l'):  # List layers
            self._list_layers()
    
    def _update_layer_visibility(self):
        for i, (marker, uncorrected_marker) in enumerate(zip(self.markers, self.uncorrected_markers)):
            is_visible = (i == self.current_layer_index)
            marker.setVisible(is_visible)
            uncorrected_marker.setVisible(is_visible)
        
        current_layer_data = self.processed_layers[self.current_layer_index]
        print(f"\nSwitched to layer: {Path(current_layer_data['image_path']).name}")
    
    def _list_layers(self):
        print(f"\n--- Available Layers ---")
        for i, layer_data in enumerate(self.processed_layers):
            marker = "→" if i == self.current_layer_index else " "
            print(f"{marker} {i+1}: {Path(layer_data['image_path']).name}") 